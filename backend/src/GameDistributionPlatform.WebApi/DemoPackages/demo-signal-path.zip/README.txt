Signal Path - Dữ liệu mẫu tự viết cho GameDistributionPlatform.
Bắt đầu từ S, đi ngang hoặc dọc trên ô trống để đến E.
Gói này chỉ chứa dữ liệu bản đồ.
